# from firedrake import *
# print(linear_elastic_constitutive_model(1.5, 2.0))
